#include <conio.h>

// structure to hold operational variables to operate conio for the X16, and make it code efficient.

void screenlayer0();
void screenlayer1();