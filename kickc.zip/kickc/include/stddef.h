
#ifndef _HAVE_NULL
/// NULL pointer
#define NULL    0
#define _HAVE_NULL
#endif

/// The unsigned integral type that is the result of the sizeof keyword.
typedef unsigned int size_t ;