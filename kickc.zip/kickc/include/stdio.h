/// @file
/// Functions for performing input and output.

#include <stddef.h>
#include <printf.h>
#include <sprintf.h>