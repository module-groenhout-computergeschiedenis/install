// Hello World for MEGA 65 - using stdio.h and conio.h
#pragma target(mega65)
#include <stdio.h>

void main() {
    printf("hello world!");
}