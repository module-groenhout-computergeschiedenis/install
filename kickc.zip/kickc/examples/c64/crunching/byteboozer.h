// ByteBoozer decruncher
// https://github.com/p-a/kickass-cruncher-plugins

// Decrunch crunched data using ByteBoozer
// - crunched: Pointer to the start of the crunched data
void byteboozer_decrunch(char* crunched);
