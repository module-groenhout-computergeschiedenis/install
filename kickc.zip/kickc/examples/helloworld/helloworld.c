#include <stdio.h>

void main() {
    printf("hello world!\n");
}
